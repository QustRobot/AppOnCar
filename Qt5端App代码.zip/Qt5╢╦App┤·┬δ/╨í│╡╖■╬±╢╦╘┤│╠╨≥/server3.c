#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <fcntl.h>
#include <termios.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <pthread.h>
#include <sys/socket.h>
#include <wiringPi.h>
#include <softPwm.h>
#include <time.h>
#include <signal.h>


#define Trigf	28
#define Echof	29
#define Trigl	24
#define Echol	25
#define Trigr	21
#define Echor	22
#define LEFT	27
#define RIGHT	26
#define BUFSIZE 512

#define SERVPORT 3333
#define BACKLOG 10
#define MAX_CONNECTED_NO 10
#define MAXDATASIZE 64

int mazeActive=0;//״̬����
int shouDongActive=0;

float disf=50,disl=50,disr=50;
int SR=HIGH;
int SL=HIGH;

static int client_fd;
static char buf[MAXDATASIZE];
int ret;
pthread_t id1,id2;
int pwmvalue = 500;
void ultraInit(void)
{
    pinMode(Echof, INPUT);
    pinMode(Echor, INPUT);
    pinMode(Echol, INPUT);
    pinMode(Trigf, OUTPUT);
    pinMode(Trigr, OUTPUT);
    pinMode(Trigl, OUTPUT);
}

float disMeasure(int flr)
{
    struct timeval tv1;
    struct timeval tv2;
    long start, stop;
    float dis;

    if(flr==1)
    {

        digitalWrite(Trigf, LOW);
        delayMicroseconds(2);

        digitalWrite(Trigf, HIGH);
        delayMicroseconds(10);	  //��������������
        digitalWrite(Trigf, LOW);

        while(!(digitalRead(Echof) == 1));
        gettimeofday(&tv1, NULL);		   //��ȡ��ǰʱ��

        while(!(digitalRead(Echof) == 0));
        gettimeofday(&tv2, NULL);		   //��ȡ��ǰʱ��

        start = tv1.tv_sec * 1000000 + tv1.tv_usec;   //΢�뼶��ʱ��
        stop  = tv2.tv_sec * 1000000 + tv2.tv_usec;

        dis = (float)(stop - start) / 1000000 * 34000 / 2;  //�������
    }
    else if(flr==2)
    {
        digitalWrite(Trigl, LOW);
        delayMicroseconds(2);

        digitalWrite(Trigl, HIGH);
        delayMicroseconds(10);	  //��������������
        digitalWrite(Trigl, LOW);

        while(!(digitalRead(Echol) == 1));
        gettimeofday(&tv1, NULL);		   //��ȡ��ǰʱ��

        while(!(digitalRead(Echol) == 0));
        gettimeofday(&tv2, NULL);		   //��ȡ��ǰʱ��

        start = tv1.tv_sec * 1000000 + tv1.tv_usec;   //΢�뼶��ʱ��
        stop  = tv2.tv_sec * 1000000 + tv2.tv_usec;

        dis = (float)(stop - start) / 1000000 * 34000 / 2;  //�������

    }
    else if(flr==3)
    {
        digitalWrite(Trigr, LOW);
        delayMicroseconds(2);

        digitalWrite(Trigr, HIGH);
        delayMicroseconds(10);	  //��������������
        digitalWrite(Trigr, LOW);

        while(!(digitalRead(Echor) == 1));
        gettimeofday(&tv1, NULL);		   //��ȡ��ǰʱ��

        while(!(digitalRead(Echor) == 0));
        gettimeofday(&tv2, NULL);		   //��ȡ��ǰʱ��

        start = tv1.tv_sec * 1000000 + tv1.tv_usec;   //΢�뼶��ʱ��
        stop  = tv2.tv_sec * 1000000 + tv2.tv_usec;

        dis = (float)(stop - start) / 1000000 * 34000 / 2;  //�������

    }
    return dis;
}
void run()      		   //ǰ��
{
    softPwmWrite(4,0);     //����ǰ��
    softPwmWrite(1,pwmvalue);
    softPwmWrite(6,0);     //����ǰ��
    softPwmWrite(5,pwmvalue);
}

void brake(int time)       //ֹͣ
{
    softPwmWrite(1,0);
    softPwmWrite(4,0);
    softPwmWrite(5,0);
    softPwmWrite(6,0);
    delay(time * 100);
}

void left(int time)        //��ת
{
    softPwmWrite(1,0);     //���ֺ���
    softPwmWrite(4,pwmvalue);
    softPwmWrite(5,pwmvalue);   //����ǰ��
    softPwmWrite(6,0);
    delay(time * 100);
}

void right(int time)            //��ת
{
    softPwmWrite(1,pwmvalue);   //����ǰ��
    softPwmWrite(4,0);
    softPwmWrite(5,0);          //���ֺ���
    softPwmWrite(6,pwmvalue);
    delay(time * 100);
}



void back(int time)             //����
{
    softPwmWrite(4,pwmvalue);   //���ֺ���
    softPwmWrite(1,0);
    softPwmWrite(6,pwmvalue);   //���ֺ���
    softPwmWrite(5,0);
    delay(time *100);
}

void shouDongThread()
{
    brake(1);
    printf("shouDongThread start!!\n");
    while(1)
    {
        if(mazeActive==0)
        {
            switch(shouDongActive)
            {
            case 0:
                brake(1);
                break;
            case 1:
                run();
                break;
            case 2:
                back();
                break;
            case 3:
                left(1);
                break;
            case 4:
                right(1);
                break;
            default:
                break;
            }
        }
    }
}

void  socketThread()
{
    struct sockaddr_in server_sockaddr,client_sockaddr;
    int sin_size=1,recvbytes;
    int sockfd;//client_fd;

    if((sockfd=socket(AF_INET,SOCK_STREAM,0))==-1)
    {
        perror("socket");
        exit(1);
    }
    printf("socket success! sockfd=%d\n",sockfd);
////
    int val = 1;
    int ret = setsockopt(sockfd,SOL_SOCKET,SO_REUSEADDR,(void *)&val,sizeof(int));
    if(ret == -1)
    {
        printf("setsockopt");
    }
////
    server_sockaddr.sin_family=AF_INET;
    server_sockaddr.sin_port=htons(SERVPORT);
    server_sockaddr.sin_addr.s_addr=INADDR_ANY;
    bzero(&(server_sockaddr.sin_zero),8);

    if(bind(sockfd,(struct sockaddr *)&server_sockaddr,sizeof(struct sockaddr))==-1)
    {
        perror("bind");
        exit(1);
    }
    printf("bind success!\n");
    if(listen(sockfd,BACKLOG)==-1)
    {
        perror("listen");
        exit(1);
    }
    printf("listen success\n");
    if((client_fd=accept(sockfd,(struct sockaddr *)&client_sockaddr,&sin_size))==-1)
    {
        perror("accept");
        exit(1);
    }
    printf("accept success\n");

    while(1)
    {
        if((recvbytes=recv(client_fd,buf,1,0))>0)
        {
            printf("Receive:%s\n",buf);
            switch(buf[0])
            {
            case '0':
                system("sudo killall maze");
                mazeActive = 0;
                shouDongActive = 0;
                break;
            case '1':
                system("sudo killall maze");
                mazeActive = 0;
                shouDongActive = 1;
                break;
            case '2':
                system("sudo killall maze");
                mazeActive = 0;
                shouDongActive = 2;
                break;
            case '3':
                system("sudo killall maze");
                mazeActive = 0;
                shouDongActive = 3;
                break;
            case '4':
                system("sudo killall maze");
                mazeActive = 0;
                shouDongActive = 4;
                break;
            case '5':
                system("sudo killall maze");
                system("sudo ./maze&");
                mazeActive = 0;
                shouDongActive = 0;
                printf("5!");
                break;

            case '9':
                system("sudo killall maze");
                close(client_fd);
                close(sockfd);
                printf("??123");
                mazeActive = 0;
                shouDongActive = 0;
                system("sudo ./server3&");
                exit(0);
                break;
            default:
                ;
                break;
            }
        }

        else if(recvbytes<=0)
        {
            printf("Connection closed!\n");
            close(client_fd);
            client_fd=accept(sockfd,(struct sockaddr *)&client_sockaddr,&sin_size);
        }
    }
    printf("thread over\n");
}
int main()
{
    wiringPiSetup();
    /*WiringPi GPIO*/
    pinMode (1, OUTPUT);
    pinMode (4, OUTPUT);
    pinMode (5, OUTPUT);
    pinMode (6, OUTPUT);
    softPwmCreate(1,1,500);
    softPwmCreate(4,1,500);
    softPwmCreate(5,1,500);
    softPwmCreate(6,1,500);

    ////////////////////////////////////////////�̣߳�
    ret=pthread_create(&id1,NULL,(void *) shouDongThread,NULL);//�������ֶ������߳�
    if(ret!=0)
    {
        printf("Create pthread error\n");
        exit(1);
    }
    ret=pthread_create(&id2,NULL,(void *) socketThread,NULL);//��Tcp�߳�
    if(ret!=0)
    {
        printf("Create pthread error\n");
        exit(1);
    }

    pthread_join(id1,NULL);
    pthread_join(id2,NULL);
}



