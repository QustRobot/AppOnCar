#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <termios.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <pthread.h>
#include <wiringPi.h>
#include <softPwm.h>
#include <time.h>
#include <signal.h>

#define Trigf	28
#define Echof	29
#define Trigl	24
#define Echol	25
#define Trigr	21
#define Echor	22
#define LEFT	27
#define RIGHT	26
#define BUFSIZE 512

float disf=50,disl=50,disr=50;
int SR=HIGH;
int SL=HIGH;
int pwmvalue = 500;

void run()      		   //前进
{
    softPwmWrite(4,0);     //左轮前进
	softPwmWrite(1,pwmvalue);
	softPwmWrite(6,0);     //右轮前进
	softPwmWrite(5,pwmvalue);
}

void brake(int time)       //停止
{
    softPwmWrite(1,0); 
	softPwmWrite(4,0);
	softPwmWrite(5,0); 
	softPwmWrite(6,0);
    delay(time * 100);
}

void left(int time)        //左转
{
    softPwmWrite(1,0);     //左轮后退
	softPwmWrite(4,pwmvalue);
	softPwmWrite(5,pwmvalue);   //右轮前进
	softPwmWrite(6,0);
	delay(time * 100);
}

void right(int time)            //右转
{
    softPwmWrite(1,pwmvalue);   //左轮前进
	softPwmWrite(4,0);
	softPwmWrite(5,0);          //右轮后退
	softPwmWrite(6,pwmvalue);
    delay(time * 100);	        
}



void back(int time)             //后退
{
    softPwmWrite(4,pwmvalue);   //左轮后退
	softPwmWrite(1,0);
	softPwmWrite(6,pwmvalue);   //右轮后退
  	softPwmWrite(5,0);
   delay(time *100);    
}


float disMeasure(int flr)       //计算三个方向的距离
{
  struct timeval tv1;
  struct timeval tv2;
  long start, stop;
  float dis;

if(flr==1){

  digitalWrite(Trigf, LOW);
  delayMicroseconds(2);

  digitalWrite(Trigf, HIGH);
  delayMicroseconds(10);	    //发出超声波脉冲
  digitalWrite(Trigf, LOW);

  while(!(digitalRead(Echof) == 1));
  gettimeofday(&tv1, NULL);	    //获取当前时间

  while(!(digitalRead(Echof) == 0));
  gettimeofday(&tv2, NULL);		//获取当前时间

  start = tv1.tv_sec * 1000000 + tv1.tv_usec;   //微秒级的时间
  stop  = tv2.tv_sec * 1000000 + tv2.tv_usec;

  dis = (float)(stop - start) / 1000000 * 34000 / 2;  //求出距离
}
else if(flr==2){
  digitalWrite(Trigl, LOW);
  delayMicroseconds(2);

  digitalWrite(Trigl, HIGH);
  delayMicroseconds(10);	  //发出超声波脉冲
  digitalWrite(Trigl, LOW);

  while(!(digitalRead(Echol) == 1));
  gettimeofday(&tv1, NULL);		   //获取当前时间

  while(!(digitalRead(Echol) == 0));
  gettimeofday(&tv2, NULL);		   //获取当前时间

  start = tv1.tv_sec * 1000000 + tv1.tv_usec;   //微秒级的时间
  stop  = tv2.tv_sec * 1000000 + tv2.tv_usec;

  dis = (float)(stop - start) / 1000000 * 34000 / 2;  //求出距离

}
else if(flr==3){
  digitalWrite(Trigr, LOW);
  delayMicroseconds(2);

  digitalWrite(Trigr, HIGH);
  delayMicroseconds(10);	  //发出超声波脉冲
  digitalWrite(Trigr, LOW);

  while(!(digitalRead(Echor) == 1));
  gettimeofday(&tv1, NULL);		   //获取当前时间

  while(!(digitalRead(Echor) == 0));
  gettimeofday(&tv2, NULL);		   //获取当前时间

  start = tv1.tv_sec * 1000000 + tv1.tv_usec;   //微秒级的时间
  stop  = tv2.tv_sec * 1000000 + tv2.tv_usec;

  dis = (float)(stop - start) / 1000000 * 34000 / 2;  //求出距离

}
  return dis;
}


void main()
{
	wiringPiSetup();
    /*WiringPi GPIO*/
    pinMode (1, OUTPUT);	//IN1
    pinMode (4, OUTPUT);	//
    pinMode (5, OUTPUT);	//IN3
    pinMode (6, OUTPUT);	//IN4
    softPwmCreate(1,1,500);
    softPwmCreate(4,1,500);
    softPwmCreate(5,1,500);
    softPwmCreate(6,1,500);

    printf("mazeThread start!!\n");
    while(1)
    {
		//获取当前三个方向的距离和两个光传感器的信号
			disf = disMeasure(1);
            disl = disMeasure(2);
            disr = disMeasure(3);
			SR = digitalRead(RIGHT);
            SL = digitalRead(LEFT);

             if(SL==HIGH && SR==HIGH && (disf<25||disf>2000))  //测得前方障碍的距离小于30cm时做出如下响应
            {
              if((disr<20||disr>2000)&&(disl<20||disl >2000)) //两侧都有障碍
              {
				brake(1);		
                left(10);//180度掉头 需要实际调整！！！
              }
              else if(disr<disl)//只有右侧有障碍物体
              {
				brake(1);
                left(5);//左转
				delay(50);
              }
              else//左边有障碍
              {
				brake(1);
                right(5);//右转
				delay(50);
              }
            }

		 if(SL==LOW && SR==LOW) //光传感器有信号，近距离两侧都有障碍
		{
				if(disr<disl){back(2);left(4);}  //向距离大的一侧转弯调整
					else {back(2);right(4);}
		}
		else if(SL==LOW || SR==LOW)//近距离一侧有障碍
		{
			if(disr<disl){back(2);left(2);}      //向距离大的一侧转弯调整
					else {back(2);right(2);}
		} 
		else//没有障碍
		{
			run();
			delay(100);
		}
		}
}
