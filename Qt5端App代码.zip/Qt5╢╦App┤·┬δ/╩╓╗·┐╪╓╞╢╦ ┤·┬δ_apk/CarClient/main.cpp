#include <QApplication>

#include"sclient.h"

int main(int argc, char *argv[])
{
    QApplication app(argc,argv);
    SClient sclient;
    sclient.showMaximized();//务必最大化显示，否则手机的界面可能包含黑边，显示不全
    return app.exec();
}
