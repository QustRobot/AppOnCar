#include<QtGui>
#include<QtNetwork>

#include "sclient.h"

SClient::SClient(QWidget *parent)
    : QDialog(parent)
{
    lcdTimerId=0;
    setupUi(this);
    colorful->setVisible(false);

    connect(&tcpSocket, SIGNAL(connected()),    this, SLOT(alreadyConnected()));                 //与tcpSoket有关的槽函数
//    connect(&tcpSocket, SIGNAL(readyRead()),    this, SLOT(updateLCD()));
    connect(&tcpSocket, SIGNAL(disconnected()), this, SLOT(connectionClosedByServer()));
    connect(&tcpSocket, SIGNAL(error(QAbstractSocket::SocketError)),  this, SLOT(error()));

    connect(connectButton,SIGNAL(clicked()),   this,SLOT(connectToServer())); //connectButton
    connect(disconnectButton,SIGNAL(clicked()),   this,SLOT(closeConnection()));//disconnectionButton

    connect(forwardButton,SIGNAL(pressed()),   this,SLOT(forward()));//press button //用按钮的按压与释放信号，实现小车手动触发动作
    connect(backButton,SIGNAL(pressed()),   this,SLOT(back()));
    connect(leftButton,SIGNAL(pressed()),   this,SLOT(left()));
    connect(rightButton,SIGNAL(pressed()),   this,SLOT(right()));
    connect(stopButton,SIGNAL(pressed()),   this,SLOT(stop()));

    connect(forwardButton,SIGNAL(released()),   this,SLOT(stop()));//release button
    connect(backButton,SIGNAL(released()),   this,SLOT(stop()));
    connect(leftButton,SIGNAL(released()),   this,SLOT(stop()));
    connect(rightButton,SIGNAL(released()),   this,SLOT(stop()));

    connect(mazeButton,SIGNAL(clicked()),   this,SLOT(maze()));

}
void SClient::stop()    {send('0');}//根据协议约定，对应出向小车服务端发送的控制字
void SClient::forward() {send('1');}
void SClient::back()    {send('2');}
void SClient::left()    {send('3');}
void SClient::right()   {send('4');}
void SClient::maze()    {send('5');}

void SClient::send(char num)//将字符型控制字通过tcp发出
{
    QByteArray block;                                                   //creat block
    QDataStream out(&block, QIODevice::WriteOnly);                      //use out
    out.setVersion(QDataStream::Qt_4_3);
    out << num ;
    tcpSocket.write(block);                             //write block
}

void SClient::connectToServer()//用于与小车服务端建立tcp连接
{   QString text;

    lcdTimerId=startTimer(50);      //timer
    tcpSocket.connectToHost(iptext->text(),3333); //address
}

void SClient::alreadyConnected()//用于连接建立后更新界面提示信息
{
    QString text;

    connectButton->setEnabled(false);       //button status
    disconnectButton->setEnabled(true);

    colorful->setVisible(true);
}


void SClient::closeConnection()//关闭连接：向服务端发送连接关闭字“9”，并将本地的tcp关闭，同时更新显示
{
    QString text;         ////////////////////////close:

    send('9');//
    tcpSocket.close();

    killTimer(lcdTimerId);
    lcdTimerId = 0;

    connectButton->setEnabled(true);
    disconnectButton->setEnabled(false);
    text+="Connection close!";
    statusBar->setText(text);
    colorful->setVisible(false);
}

void SClient::connectionClosedByServer()//若连接意外掉线，执行关闭连接
{
    closeConnection();
}

void SClient::error()
{

}

void SClient::timerEvent(QTimerEvent *event) //timer
{
    if(event->timerId()==lcdTimerId)
        ;// timeEvent, to be continue...
    else
        QWidget::timerEvent(event);
}

//void SClient::showEvent(QShowEvent *event)
//{
//    lcdTimerId = startTimer(100);
//}

void SClient::hideEvent(QHideEvent *event)
{
    killTimer(lcdTimerId);
    lcdTimerId = 0;
}
