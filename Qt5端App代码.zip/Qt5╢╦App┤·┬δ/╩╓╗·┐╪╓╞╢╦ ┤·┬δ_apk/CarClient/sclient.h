#ifndef SCLIENT_H
#define SCLIENT_H

#include <QDialog>
#include <QTcpSocket>       //Add

#include "ui_sclient.h"

class SClient: public QDialog,public::Ui::SClient
{
    Q_OBJECT
public:
    SClient(QWidget *parent = 0);
private slots:
    void connectToServer();
    void alreadyConnected();

    void forward();
    void back();
    void left();
    void right();
    void stop();
    void maze();
    void send(char num);

    void connectionClosedByServer();
    void error();
    void closeConnection();

private:
    QTcpSocket tcpSocket;
    int lcdTimerId;
//    quint8 code;
//    quint8 channel;
//    quint8 receiveData[4];
//    int displayData;

protected:
    void timerEvent(QTimerEvent *event);
//    void showEvent(QShowEvent *event);
    void hideEvent(QHideEvent *event);

};
#endif // SCLIENT_H
