//app.js
App({
    onLaunch: function() {
        // 展示本地存储能力
        var logs = wx.getStorageSync('logs') || []
        logs.unshift(Date.now())
        wx.setStorageSync('logs', logs)

    },
    globalData: {
        userInfo: null,
        webSocketUrl:'ws://192.168.12.1:8181',
        httpUrl:'http://192.168.12.1:8282'
    }
})