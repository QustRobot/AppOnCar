// pages/menu/menu.js
Page({

    data: {

    },

    onLoad: function(options) {

    },

    visitControl:function(){
        let that = this
        wx.navigateTo({
            url: '/pages/control/control',
        })
    },

    visitAccelerate:function(){
        let that = this
        wx.navigateTo({
            url: '/pages/accelerate/accelerate',
        })
    }
})