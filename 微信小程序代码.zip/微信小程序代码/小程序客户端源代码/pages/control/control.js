const app = getApp()

Page({

    data: {
        flag: 0
    },

    onLoad: function() {
        let that = this
        const SocketTask = wx.connectSocket({
            url: app.globalData.webSocketUrl,
            header: {

            },
            protocols: [],
            success: res => {
                console.log(res)
            }
        })

        SocketTask.onOpen((res) => {
            console.log('WebSocket连接打开')
            console.log(res)
        })

        SocketTask.onClose(() => {
            console.log('WebSocket连接关闭')
        })

        SocketTask.onError((res) => {
            console.log('WebSocket连接发生错误')
            console.log(res)
        })

        SocketTask.onMessage((res) => {
            console.log('WebSocket接收到服务器的消息')
            console.log(res)
        })

        that.setData({
            SocketTask: SocketTask
        })
    },

    makeCarUp: function() {
        let that = this
        let SocketTask = that.data.SocketTask
        let flag = that.data.flag
        if (flag == 1) {
            SocketTask.send({
                data: "up",
                success: res => {
                    console.log(res)
                }
            })
        } else {
            wx.request({
                url: app.globalData.httpUrl + '/up',
            })
        }


    },

    makeCarBrake: function() {
        console.log('stop');
        wx.request({
            url: app.globalData.httpUrl + '/brake',
        })
    },

    makeCarDown: function() {
        let that = this
        let flag = that.data.flag
        if (flag == 1) {
            wx.sendSocketMessage({
                data: [
                    'down'
                ],
            })
        } else {
            wx.request({
                url: app.globalData.httpUrl + '/back',
            })
        }
    },

    makeCarLeft: function() {
        let that = this
        let flag = that.data.flag
        if (flag == 1) {
            wx.sendSocketMessage({
                data: [
                    'left'
                ],
            })
        } else {
            wx.request({
                url: app.globalData.httpUrl + '/left',
            })
        }

    },

    makeCarRight: function() {
        let that = this
        let flag = that.data.flag
        if (flag == 1) {
            wx.sendSocketMessage({
                data: [
                    'right'
                ],
            })
        } else {
            wx.request({
                url: app.globalData.httpUrl + '/right',
            })
        }
    },

    changeContact: function(e) {
        let that = this
        that.setData({
            flag: e.currentTarget.dataset.id
        })
    }
})