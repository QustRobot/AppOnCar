// pages/accelerate/accelerate.js
const app = getApp()

Page({

    data: {

    },

    onLoad: function() {
        let that = this

        wx.connectSocket({
            url: app.globalData.webSocketUrl,
            success: res => {
                console.log(res)
            }
        })

        wx.onSocketOpen((res) => {
            console.log('WebSocket连接已打开')
        })

        wx.onSocketError((res) => {
            console.log('WebSocket连接打开失败，请检查')
        })



        // const SocketTask = wx.connectSocket({
        //     url: app.globalData.webSocketUrl,
        //     header: {

        //     },
        //     protocols: [],
        //     success: res => {
        //         console.log(res)
        //     }
        // })

        // SocketTask.onOpen((res) => {
        //     console.log('WebSocket连接打开')
        //     console.log(res)
        // })

        // SocketTask.onClose(() => {
        //     console.log('WebSocket连接关闭')
        // })

        // SocketTask.onError((res) => {
        //     console.log('WebSocket连接发生错误')
        //     console.log(res)
        // })

        // SocketTask.onMessage((res) => {
        //     console.log('WebSocket接收到服务器的消息')
        //     console.log(res)
        // })

        wx.startAccelerometer({
            interval: 'normal',
            success: res => {
                console.log(res)
            }
        })
        wx.onAccelerometerChange(function(res) {
            console.log(res.x)
            console.log(res.y)
            console.log(res.z)
            that.setData({
                xNumber: res.x,
                yNumber: res.y,
                zNumber: res.z
            })
            if (res.x > 0 && res.y > 0) {
                // SocketTask.send({
                //     data: "up",
                //     success: res => {
                //         console.log(res)
                //     }
                // })
                console.log('up')
                wx.sendSocketMessage({
                    data: [
                        'up'
                    ],
                })
            } else if (res.x < 0 && res.y > 0) {
                // SocketTask.send({
                //     data: "left",
                //     success: res => {
                //         console.log(res)
                //     }
                // })
                console.log('left')
                wx.sendSocketMessage({
                    data: [
                        'left'
                    ],
                })
            } else if (res.x > 0 && res.y < 0) {
                // SocketTask.send({
                //     data: "right",
                //     success: res => {
                //         console.log(res)
                //     }
                // })
                console.log('right')
                wx.sendSocketMessage({
                    data: [
                        'right'
                    ],
                })
            } else if (res.x > 0 && res.y < 0) {
                // SocketTask.send({
                //     data: "down",
                //     success: res => {
                //         console.log(res)
                //     }
                // })
                console.log('down')
                wx.sendSocketMessage({
                    data: [
                        'down'
                    ],
                })
            }
        })
    },
})