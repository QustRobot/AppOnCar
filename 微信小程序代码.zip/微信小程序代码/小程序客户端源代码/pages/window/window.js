// pages/window/window.js
const app = getApp()
Page({

    //页面的初始数据
    data: {
        httpUrl: app.globalData.httpUrl,
        webSocketUrl: app.globalData.webSocketUrl
    },

    //监听页面加载
    onLoad: function() {

    },

    //点击连接
    tapContact: function() {
        let that = this
        wx.scanCode({
            onlyFromCamera: false,
            scanType: ['qrCode'],
            success: res => {
                if (res.result == 'qust-pi-318') {
                    wx.showToast({
                        title: '扫描成功',
                    })
                    wx.navigateTo({
                        url: '/pages/menu/menu',
                    })
                } else {
                    wx.showToast({
                        title: '扫描错误',
                        image: '/icon/error.png'
                    })
                }
            },
            fail: res => {
                wx.showToast({
                    title: '扫描失败',
                    image: '/icon/error.png'
                })
            }
        })
    },

    inputHttpUrl: function(e) {
        let that = this
        that.setData({
            httpUrl: e.detail.value
        })
        app.globalData.httpUrl = that.data.httpUrl
    },

    inputWebSocketUrl: function(e) {
        let that = this
        that.setData({
            webSocketUrl: e.detail.value
        })
        app.globalData.webSocketUrl = that.data.webSocketUrl
    }
})