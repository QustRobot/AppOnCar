const WebSocketServer = require('ws').Server;
const wss = new WebSocketServer({ port: 9090 });
const rpio = require('rpio');
const express = require('express');
const app = express();

function Motor(pins) {
    this.pins = pins || [12, 16, 18, 22];
    this.flags = {
        upFlag: false,
        backFlag: false,
        leftFlag: false,
        rightFlag: false
    }
    this._initGpio();
    return this;
}

Motor.prototype = {
    _initGpio: function () {
        this.pins.forEach(pin => {
            rpio.open(pin, rpio.OUTPUT);
            console.log(`${pin} is open!`)
        });
    },
    _initFlag: function () {
        this.flags.upFlag = false;
        this.flags.backFlag = false;
        this.flags.leftFlag = false;
        this.flags.rightFlag = false;
    },
    _run: function () {
        let pins = this.pins;
        let self = this;
        this.flags.upFlag = true;
        while (this.flags.upFlag) {
            rpio.write(pins[0], rpio.HIGH);
            rpio.write(pins[1], rpio.LOW);
            rpio.write(pins[2], rpio.HIGH);
            rpio.write(pins[3], rpio.LOW);
            app.get('/brake',function(req,res){
                console.log('stop')
                self.flags.upFlag = false;
            })
        }
    },
    _brake: function () {
        let pins = this.pins;
        this.flags.upFlag = false;
        rpio.write(pins[0], rpio.LOW);
        rpio.write(pins[1], rpio.LOW);
        rpio.write(pins[2], rpio.LOW);
        rpio.write(pins[3], rpio.LOW);
    },
    _left: function () {
        let pins = this.pins;
        this.flags.leftFlag = true;
        while (this.flags.leftFlag) {
            rpio.write(pins[0], rpio.LOW);
            rpio.write(pins[1], rpio.HIGH);
            rpio.write(pins[2], rpio.HIGH);
            rpio.write(pins[3], rpio.LOW);
        }
    },
    _right: function () {
        let pins = this.pins;
        this.flags.rightFlag = true;
        while (this.flags.rightFlag) {
            rpio.write(pins[0], rpio.HIGH);
            rpio.write(pins[1], rpio.LOW);
            rpio.write(pins[2], rpio.LOW);
            rpio.write(pins[3], rpio.HIGH);
        }
    },
    _back:function(){
        let pins = this.pins;
        this.flags.backFlag = true;
        while (this.flags.backFlag) {
            rpio.write(pins[0], rpio.LOW);
            rpio.write(pins[1], rpio.HIGH);
            rpio.write(pins[2], rpio.LOW);
            rpio.write(pins[3], rpio.HIGH);
        }
    }
}

let motor = new Motor();

wss.on('connection', function (ws) {
    console.log('client connected');
    ws.on('message', function (message) {
        if (message == 'up') {
            console.log('小车向前走');
            motor._initFlag();
            motor._run();
        }
    })
    ws.on('message', function (message) {
        if (message == 'left') {
            console.log("小车向左转弯");
            motor._initFlag();
            motor._left();
        }
    })
})

app.get('/up', function (req, res) {
    console.log('小车向前走');
    motor._run();
})

app.get('/brake', function (req, res) {
    console.log('停止运转')
    motor._brake();
})

app.get('/left', function (req, res) {
    console.log('小车向左转弯')
    motor._left();
})

app.get('/right',function(req,res){
    console.log('小车向右转弯');
    motor._right();
})

app.get('/back',function(req,res){
    console.log('小车向后走');
    motor._back();
})



app.listen(8282);
