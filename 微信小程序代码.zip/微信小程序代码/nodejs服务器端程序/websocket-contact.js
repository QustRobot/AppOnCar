const WebSocketServer = require('ws').Server;
const wss = new WebSocketServer({ port: 8181 });
const gpio = require('pi-gpio');

let errhandle = function (err) {
    if (err) {
        console.error(err)
    }
}


let up = true;
wss.on('connection', function (ws) {
    console.log('client connected');
    ws.on('message', function (message) {
        if (message == 'up') {
            console.log('小车向前走')
            gpio.open(12, 'output', function (err) {
                if (err) {
                    console.log(err)
                } else {
                    gpio.write(12, 1, function (err) {
                        if (err) {
                            console.error(err)
                        } else {
                            gpio.close(12, function (err) {
                                if (err) {
                                    console.error(err)
                                }
                            })
                        }
                    })
                }
            })
            gpio.open(16, 'output', function (err) {
                if (err) {
                    console.log(err)
                } else {
                    gpio.write(16, 0, function (err) {
                        if (err) {
                            console.error(err)
                        } else {
                            gpio.close(16, function (err) {
                                if (err) {
                                    console.error(err)
                                }
                            })
                        }
                    })
                }
            })
            gpio.open(18, 'output', function (err) {
                if (err) {
                    console.log(err)
                } else {
                    gpio.write(18, 1, function (err) {
                        if (err) {
                            console.error(err)
                        } else {
                            gpio.close(18, function (err) {
                                if (err) {
                                    console.error(err)
                                }
                            })
                        }
                    })
                }
            })
            gpio.open(22, 'output', function (err) {
                if (err) {
                    console.log(err)
                } else {
                    gpio.write(22, 0, function (err) {
                        if (err) {
                            console.error(err)
                        } else {
                            gpio.close(22, function (err) {
                                if (err) {
                                    console.error(err)
                                }
                            })
                        }
                    })
                }
            })
        } else if (message == 'down') {
            console.log('小车后退')
            gpio.open(12, 'output', function (err) {
                if (err) {
                    console.log(err)
                } else {
                    gpio.write(12, 0, function (err) {
                        if (err) {
                            console.error(err)
                        } else {
                            gpio.close(12, function (err) {
                                if (err) {
                                    console.error(err)
                                }
                            })
                        }
                    })
                }
            });
            gpio.open(16, 'output', function (err) {
                if (err) {
                    console.log(err)
                } else {
                    gpio.write(16, 1, function (err) {
                        if (err) {
                            console.error(err)
                        } else {
                            gpio.close(16, function (err) {
                                if (err) {
                                    console.error(err)
                                }
                            })
                        }
                    })
                }
            })
            gpio.open(18, 'output', function (err) {
                if (err) {
                    console.log(err)
                } else {
                    gpio.write(18, 0, function (err) {
                        if (err) {
                            console.error(err)
                        } else {
                            gpio.close(18, function (err) {
                                if (err) {
                                    console.error(err)
                                }
                            })
                        }
                    })
                }
            })
            gpio.open(22, 'output', function (err) {
                if (err) {
                    console.log(err)
                } else {
                    gpio.write(22, 1, function (err) {
                        if (err) {
                            console.error(err)
                        } else {
                            gpio.close(22, function (err) {
                                if (err) {
                                    console.error(err)
                                }
                            })
                        }
                    })
                }
            })
        } else if (message == 'left') {
            console.log('小车向左转弯')
            gpio.open(12, 'output', function (err) {
                if (err) {
                    console.log(err)
                } else {
                    gpio.write(12, 0, function (err) {
                        if (err) {
                            console.error(err)
                        } else {
                            gpio.close(12, function (err) {
                                if (err) {
                                    console.error(err)
                                }
                            })
                        }
                    })
                }
            })
            gpio.open(16, 'output', function (err) {
                if (err) {
                    console.log(err)
                } else {
                    gpio.write(16, 0, function (err) {
                        if (err) {
                            console.error(err)
                        } else {
                            gpio.close(16, function (err) {
                                if (err) {
                                    console.error(err)
                                }
                            })
                        }
                    })
                }
            })
            gpio.open(18, 'output', function (err) {
                if (err) {
                    console.log(err)
                } else {
                    gpio.write(18, 1, function (err) {
                        if (err) {
                            console.error(err)
                        } else {
                            gpio.close(18, function (err) {
                                if (err) {
                                    console.error(err)
                                }
                            })
                        }
                    })
                }
            })
            gpio.open(22, 'output', function (err) {
                if (err) {
                    console.log(err)
                } else {
                    gpio.write(22, 0, function (err) {
                        if (err) {
                            console.error(err)
                        } else {
                            gpio.close(22, function (err) {
                                if (err) {
                                    console.error(err)
                                }
                            })
                        }
                    })
                }
            })
        } else if (message == 'right') {
            console.log('小车向右转弯')
            gpio.open(12, 'output', function (err) {
                if (err) {
                    console.log(err)
                } else {
                    gpio.write(12, 1, function (err) {
                        if (err) {
                            console.error(err)
                        } else {
                            gpio.close(12, function (err) {
                                if (err) {
                                    console.error(err)
                                }
                            })
                        }
                    })
                }
            })
            gpio.open(16, 'output', function (err) {
                if (err) {
                    console.log(err)
                } else {
                    gpio.write(16, 0, function (err) {
                        if (err) {
                            console.error(err)
                        } else {
                            gpio.close(16, function (err) {
                                if (err) {
                                    console.error(err)
                                }
                            })
                        }
                    })
                }
            })
            gpio.open(18, 'output', function (err) {
                if (err) {
                    console.log(err)
                } else {
                    gpio.write(18, 0, function (err) {
                        if (err) {
                            console.error(err)
                        } else {
                            gpio.close(18, function (err) {
                                if (err) {
                                    console.error(err)
                                }
                            })
                        }
                    })
                }
            })
            gpio.open(22, 'output', function (err) {
                if (err) {
                    console.log(err)
                } else {
                    gpio.write(22, 0, function (err) {
                        if (err) {
                            console.error(err)
                        } else {
                            gpio.close(22, function (err) {
                                if (err) {
                                    console.error(err)
                                }
                            })
                        }
                    })
                }
            })
        } else {
            console.log(message)
        }
    });

    ws.on('close', (code, reason) => {
        console.log(code);
        console.log(reason);
    })
});
