#include <stdio.h>
#include <stdlib.h>
#include <softPwm.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <time.h>
#include <wiringPi.h>
#define Trig	28//前端发射超声波端口
#define Echo	29//前端接收超声波端口
#define TrigLeft	24//左端发射超声波端口
#define EchoLeft	25//左端接收超声波端口
#define TrigRight	21//右端发射超声波端口
#define EchoRight	22//右端接收超声波端口
#define BUFSIZE 512
void ultraInit(void)
{
  pinMode(Echo, INPUT);
  pinMode(Trig, OUTPUT);
  pinMode(EchoLeft, INPUT);
  pinMode(TrigLeft, OUTPUT);
  pinMode(EchoRight, INPUT);
  pinMode(TrigRight, OUTPUT);
}

float disMeasure(int flag)
{
  struct timeval tv1;
  struct timeval tv2;
  long start, stop;
  float dis;
  
  if(flag == 0){
	  digitalWrite(Trig, LOW);
	  delayMicroseconds(2);

	  digitalWrite(Trig, HIGH);
	  delayMicroseconds(10);	  //发出超声波脉冲
	  digitalWrite(Trig, LOW);
	  
	  while(!(digitalRead(Echo) == 1));
	  gettimeofday(&tv1, NULL);		   //获取当前时间

	  while(!(digitalRead(Echo) == 0));
	  gettimeofday(&tv2, NULL);		   //获取当前时间
  }else if(flag == 1){
	  digitalWrite(TrigLeft, LOW);
	  delayMicroseconds(2);

	  digitalWrite(TrigLeft, HIGH);
	  delayMicroseconds(10);
	  digitalWrite(TrigLeft, LOW);
	  
	  while(!(digitalRead(EchoLeft) == 1));
	  gettimeofday(&tv1, NULL);	

	  while(!(digitalRead(EchoLeft) == 0));
	  gettimeofday(&tv2, NULL);
  }else if(flag == 2){
	  digitalWrite(TrigRight, LOW);
	  delayMicroseconds(2);

	  digitalWrite(TrigRight, HIGH);
	  delayMicroseconds(10);
	  digitalWrite(TrigRight, LOW);
	  
	  while(!(digitalRead(EchoRight) == 1));
	  gettimeofday(&tv1, NULL);

	  while(!(digitalRead(EchoRight) == 0));
	  gettimeofday(&tv2, NULL);
  }

  start = tv1.tv_sec * 1000000 + tv1.tv_usec;   //微秒级的时间
  stop  = tv2.tv_sec * 1000000 + tv2.tv_usec;

  dis = (float)(stop - start) / 1000000 * 34000 / 2;  //求出距离

  return dis;
}

void run()     // 前进
{
    softPwmWrite(4,0); //左轮前进
	softPwmWrite(1,100); 
	softPwmWrite(6,0); //右轮前进
	softPwmWrite(5,100); 
}

void brake(int time)         //刹车，停车
{
    softPwmWrite(1,0); //左轮stop
	softPwmWrite(4,0); 
	softPwmWrite(5,0); //stop
	softPwmWrite(6,0); 
    delay(time);//执行时间，可以调整  
}

void left(int time)         //左转(左轮不动，右轮前进)
{
    softPwmWrite(1,0); //左轮stop
	softPwmWrite(4,250); 
	softPwmWrite(5,250); //右轮前进
	softPwmWrite(6,0); 
	delay(time);
}



void right(int time)        //右转(右轮不动，左轮前进)
{
    softPwmWrite(1,250); //左轮前进
	softPwmWrite(4,0); 
	softPwmWrite(5,0); //右轮stop
	softPwmWrite(6,250); 
    delay(time);	//执行时间，可以调整  
}



void back(int time)          //后退
{
    softPwmWrite(4,250); //左轮back
	softPwmWrite(1,0); 
	softPwmWrite(6,250); //右轮back
  	softPwmWrite(5,0); 
    delay(time);     //执行时间，可以调整  
}
int main(int argc, char *argv[])
{

    float dis,disLeft,disRight;
	int upFlag = 0;
	int leftFlag = 1;
	int rightFlag = 2;
	
	
	ultraInit();

   // char buf[BUFSIZE]={0xff,0x00,0x00,0x00,0xff};


    /*RPI*/
    wiringPiSetup();
    /*WiringPi GPIO*/
    pinMode (1, OUTPUT);	//IN1
    pinMode (4, OUTPUT);	//IN2
    pinMode (5, OUTPUT);	//IN3
    pinMode (6, OUTPUT);	//IN4
    softPwmCreate(1,1,100);   
    softPwmCreate(4,1,100);
    softPwmCreate(5,1,100);
    softPwmCreate(6,1,100);
  while(1){
    dis = disMeasure(upFlag);
	disLeft = disMeasure(leftFlag)-40;
	disRight = disMeasure(rightFlag);
    printf("前distance = %0.2f cm\n",dis);//输出当前超声波测得的距离
    printf("左distance = %0.2f cm\n",disLeft);
	printf("右distance = %0.2f cm\n",disRight);
	//run();
	if(dis<20){   //测得前方r69障碍的距离小于30cm时做出如下响应
		if(disLeft>disRight){
			printf("左转\n");
			left(300);//左转300
		}
		else if(disLeft<disRight){
			printf("右转\n");
			right(300);
		}
			
      }
     else{
		 run();
	 }
  }
  return 0;

}

